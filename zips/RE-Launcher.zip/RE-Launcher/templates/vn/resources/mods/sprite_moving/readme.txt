The mod takes sprites registered in rpy-files from mods/common/

You can move sprites with the mouse (the selected sprite is moved, not the one under the mouse cursor).
By default, movement occurs along the X and Y axes, while pressing Ctrl - only along X.

* Ctrl+C - copy the code that will display the current sprites.
This function does not take on the task of setting up the as (pseudonym) and with (effect) parameters;

* H - hide panels and enlarge sprite screen to normal size;
* R - reset the parameters of the selected sprite to default values.
